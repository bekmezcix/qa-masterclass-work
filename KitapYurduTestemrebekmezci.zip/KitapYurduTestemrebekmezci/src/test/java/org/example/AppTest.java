package org.example;

import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

public class AppTest {

    @Test
    public void sampleTest() {
        assertTrue(true, "Bu test her zaman geçer.");
    }
}

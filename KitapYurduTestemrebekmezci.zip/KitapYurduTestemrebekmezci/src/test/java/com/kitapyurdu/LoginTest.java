package com.kitapyurdu;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class LoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup(); // ChromeDriver yönetimi
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Explicit wait
    }

    @Test
    public void validLoginTest() {
        driver.get("https://www.kitapyurdu.com/");

        // Giriş butonuna tıkla
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Giriş Yap")));
        loginButton.click();

        // Eposta gir
        WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-email")));
        emailInput.sendKeys("dogruemail@example.com"); // ← kendi epostanı yaz

        // Şifre gir
        WebElement passwordInput = driver.findElement(By.id("login-password"));
        passwordInput.sendKeys("DogruSifre123"); // ← kendi şifreni yaz

        // Giriş butonuna tıkla
        WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-button")));
        submitButton.click();

        // Kullanıcı adı kontrolü (başarılı login sonrası)
        WebElement userElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.user > a")));
        String actualUsername = userElement.getText();

        Assert.assertTrue(actualUsername.length() > 0, "Login başarısız. Kullanıcı adı görünmedi.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Tarayıcıyı kapat
        }
    }
}

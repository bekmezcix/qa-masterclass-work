package com.kitapyurdu;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
public class VerifyCartItemTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }

    @Test
    public void verifyCartItemTest() {
        // Sepet sayfasını aç
        driver.get("https://www.kitapyurdu.com/index.php?route=checkout/cart");

        // Sepetteki ürün alanını bekle
        WebElement productRow = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".cart-info tbody tr")));

        // Ürün başlığını al
        WebElement productTitle = productRow.findElement(By.cssSelector("a"));

        // Ürünün adının beklendiği gibi olup olmadığını kontrol et
        String actualProductName = productTitle.getText().toLowerCase();
        Assert.assertTrue(actualProductName.contains("miras"), "Sepette 'Miras' adlı ürün bulunamadı!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
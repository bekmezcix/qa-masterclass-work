package com.kitapyurdu;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class InvalidLoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.manage().window().maximize();
    }

    @Test
    public void testInvalidEmailFormat() {
        driver.get("https://www.kitapyurdu.com");

        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href*='login']")));
        loginButton.click();

        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-email")));
        emailField.sendKeys("gecersizmail");

        WebElement passwordField = driver.findElement(By.id("login-password"));
        passwordField.sendKeys("123456");

        WebElement submitButton = driver.findElement(By.id("login-button"));
        submitButton.click();


        wait.until(ExpectedConditions.textToBePresentInElementLocated(
                By.cssSelector("#swal2-html-container"),
                "Geçerli bir E-Posta adresi yazınız!")
        );


        WebElement messageElement = driver.findElement(By.cssSelector("#swal2-html-container"));
        String actualMessage = messageElement.getText().trim();

        Assert.assertEquals(actualMessage, "Geçerli bir E-Posta adresi yazınız!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

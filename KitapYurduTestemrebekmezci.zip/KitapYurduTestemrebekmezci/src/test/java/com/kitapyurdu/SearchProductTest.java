package com.kitapyurdu;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class SearchProductTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }

    @Test
    public void searchProduct() {
        driver.get("https://www.kitapyurdu.com/index.php?route=account/account");

        // Arama kutusunu bul ve ürün ismini yaz
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search-input")));
        searchBox.sendKeys("Nutuk");

        // Ara butonuna tıkla
        WebElement searchButton = driver.findElement(By.cssSelector("div.search-button > span"));
        searchButton.click();

        // Arama sonuçlarının yüklendiğini kontrol et
        WebElement resultsContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".product-cr")));

        // Sayfada "Nutuk" kelimesi geçen sonuçlar olduğunu doğrula
        String pageSource = driver.getPageSource().toLowerCase();
        Assert.assertTrue(pageSource.contains("nutuk"), "Nutuk arama sonucu bulunamadı!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

package com.kitapyurdu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class AddingtoCartfromProductDetailTest {
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            // 1. Kitap detay sayfasına git
            driver.get("https://www.kitapyurdu.com/kitap/miras/576119.html");

            // 2. "Sepete Ekle" butonunu bul ve tıkla
            WebElement sepeteEkleBtn = driver.findElement(By.id("button-cart"));
            sepeteEkleBtn.click();

            // 3. Sepet sayfasına git (bekleme süresi ekledik, pop-up kapanması vs. için)
            Thread.sleep(3000);
            driver.get("https://www.kitapyurdu.com/index.php?route=checkout/cart");

            // 4. Sepet sayfasında ürünün eklenip eklenmediğini kontrol et
            WebElement kitapAdi = driver.findElement(By.xpath("//a[contains(text(),'Miras')]"));
            if (kitapAdi.isDisplayed()) {
                System.out.println("Ürün sepete başarıyla eklendi.");
            } else {
                System.out.println("Ürün sepete eklenemedi.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Thread.sleep(5000); // sonucu gözlemlemek için biraz bekle
            driver.quit();
        }
    }
}
